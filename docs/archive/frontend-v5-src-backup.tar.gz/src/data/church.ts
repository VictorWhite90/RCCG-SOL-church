export const church = {
  name: "Spring of Life",
  location: "RCCG · Abuja",
  hero: {
    lines: ["Come as you are.", "Become who you’re", "called to be."],
    introduction:
      "A community built on faith, shaped by love, and growing together in Christ.",
    invitation: "There’s a place for you in our family.",
    poster: "/media/v5/hero-poster.webp",
    sources: [{ src: "/media/v5/hero-demo.mp4", type: "video/mp4" }],
  },
};

export const information = {
  stories: {
    label: "Share your story",
    eyebrow: "STORIES OF GRACE",
    title: "Every story matters.",
    description:
      "We look forward to celebrating testimonies shared with permission.",
    detail:
      "The church’s verified contact and consent process will be published before stories can be submitted. This preview does not collect personal information.",
  },
  visit: {
    label: "Plan a visit",
    eyebrow: "YOU ARE INVITED",
    title: "Your first Sunday starts here.",
    description:
      "Come as you are. We look forward to welcoming you to Spring of Life, Abuja.",
    detail:
      "Our confirmed service times, street address and visitor contact will be published here once supplied by the church. Please check back before travelling.",
  },
  sermons: {
    label: "Sermons",
    eyebrow: "GROW IN THE WORD",
    title: "A word for your journey.",
    description:
      "Messages to encourage your faith and bring the Word into everyday life.",
    detail:
      "Our approved sermon library and official livestream link are being prepared. No live broadcast is connected yet.",
  },
  prayer: {
    label: "Request prayer",
    eyebrow: "WE BELIEVE IN PRAYER",
    title: "You don’t have to walk alone.",
    description:
      "There is a place for your hopes, your questions and your prayer needs in this family.",
    detail:
      "The church’s verified prayer contact will be added here. Online prayer requests are not being collected yet.",
  },
  ministries: {
    label: "Ministries",
    eyebrow: "GET INVOLVED",
    title: "There is a place for everyone.",
    description: "A community to grow with, serve with and call home.",
    detail:
      "Ministry details and ways to get involved will follow with approved church content.",
  },
  events: {
    label: "Events",
    eyebrow: "LIFE TOGETHER",
    title: "A reason to gather.",
    description:
      "Worship, fellowship and moments that bring our church family together.",
    detail:
      "The programme calendar will be published after event dates and service information are confirmed.",
  },
  projects: {
    label: "Kingdom Projects",
    eyebrow: "BUILDING HOPE TOGETHER",
    title: "Faith that makes a difference.",
    description: "Discover the vision and the work we can support together.",
    detail:
      "Approved projects, funding targets and verified milestones will be added in a later phase. Contributions and payments are not available on this preview.",
  },
} as const;
export type InformationKey = keyof typeof information;
export const navigation: { label: string; key: InformationKey | "about" }[] = [
  { label: "Our church", key: "about" },
  { label: "Sermons", key: "sermons" },
  { label: "Ministries", key: "ministries" },
  { label: "Events", key: "events" },
  { label: "Kingdom Projects", key: "projects" },
];
