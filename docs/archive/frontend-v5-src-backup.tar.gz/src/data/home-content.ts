export const ministries = [
  {
    category: "COMMUNITY",
    title: "Find your people.",
    action: "EXPLORE MINISTRIES",
    image: "/media/v5/photo1.jpg",
    alt: "Friends greeting each other — illustrative image",
  },
  {
    category: "SERVICE",
    title: "Make an impact.",
    action: "EXPLORE WAYS TO SERVE",
    image: "/media/v5/photo3.jpg",
    alt: "Community food distribution — illustrative image",
  },
  {
    category: "WORSHIP",
    title: "Grow in faith.",
    action: "GET CONNECTED",
    image: "/media/v5/photo4.jpg",
    alt: "Congregation in worship — illustrative image",
  },
] as const;
