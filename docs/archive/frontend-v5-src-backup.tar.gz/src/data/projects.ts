export const projects = [
  {
    slug: "building-for-generations",
    category: "CHURCH DEVELOPMENT",
    title: "Building for generations",
    image: "/media/v5/photo1.jpg",
    description:
      "Creating more room for worship, learning and the next generation.",
    vision: "Room to grow. Space to belong.",
  },
  {
    slug: "love-beyond-the-walls",
    category: "COMMUNITY OUTREACH",
    title: "Love beyond the walls",
    image: "/media/v5/photo3.jpg",
    description:
      "Supporting neighbours through compassion, practical service and outreach.",
    vision: "Compassion that reaches our city.",
  },
  {
    slug: "making-room-for-the-message",
    category: "WORSHIP & MEDIA",
    title: "Making room for the message",
    image: "/media/v5/photo2.jpg",
    description:
      "Strengthening the tools and spaces that support worship and sharing the Word.",
    vision: "Sharing truth. Encouraging faith.",
  },
] as const;
export const milestones = [
  {
    title: "Define the vision",
    description: "Project scope and goals to be approved.",
  },
  {
    title: "Share progress",
    description: "Publish truthful updates, reports and photographs.",
  },
  {
    title: "Celebrate the impact",
    description: "Share completed milestones with supporters.",
  },
];
export type Project = (typeof projects)[number];
