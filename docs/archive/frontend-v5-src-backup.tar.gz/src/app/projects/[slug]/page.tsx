import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { projects, milestones } from "@/data/projects";
import { ContributionPreview } from "@/components/contribution-preview";
export function generateStaticParams() {
  return projects.map((project) => ({ slug: project.slug }));
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const project = projects.find((item) => item.slug === slug);
  return { title: `${project?.title ?? "Project not found"} | Spring of Life` };
}
export default async function ProjectPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const project = projects.find((item) => item.slug === slug);
  if (!project) notFound();
  return (
    <main id="main" className="subpage">
      <section className="detail-page section-pad">
        <div className="wrap">
          <Link className="breadcrumb" href="/projects">
            ← ALL KINGDOM PROJECTS
          </Link>
          <div className="detail-heading" data-reveal="">
            <span className="kicker">
              <span className="kicker__bar" />
              {project.category} / ILLUSTRATIVE CONCEPT
            </span>
            <h1>{project.title}</h1>
            <p>{project.description}</p>
          </div>
          <div className="detail-layout">
            <div className="detail-primary">
              <div className="detail-primary__photo" data-reveal="">
                <Image
                  src={project.image}
                  alt={`${project.title} — illustrative photo, not our church`}
                  width={1600}
                  height={1067}
                  sizes="(max-width: 760px) 100vw, 65vw"
                />
                <span>DESIGN PLACEHOLDER / PROJECT IMAGE</span>
              </div>
              <div className="detail-story" data-reveal="">
                <span className="label">THE VISION</span>
                <h2>{project.vision}</h2>
                <p>
                  This example shows the structure of a future project page.
                  Actual descriptions, budgets, contractor information,
                  photographs, milestones and progress will only be added after
                  verification and approval by RCCG Spring of Life leadership.
                </p>
                <h3>Project milestones</h3>
                {milestones.map((milestone, index) => (
                  <div className="milestone" key={milestone.title}>
                    <span>0{index + 1}</span>
                    <div>
                      <strong>{milestone.title}</strong>
                      <p>{milestone.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <ContributionPreview key={project.slug} />
          </div>
        </div>
      </section>
    </main>
  );
}
