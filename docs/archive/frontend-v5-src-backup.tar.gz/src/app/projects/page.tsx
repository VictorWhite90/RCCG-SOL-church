import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { projects } from "@/data/projects";
import { ProjectCard } from "@/components/project-card";
export const metadata: Metadata = {
  title: "Kingdom Projects | RCCG Spring of Life",
};
export default function ProjectsPage() {
  return (
    <main id="main" className="subpage">
      <section className="projects-hero">
        <div className="wrap projects-hero__inner">
          <div data-reveal="">
            <p className="kicker kicker--light">
              <span className="kicker__bar" />
              05 / OUR VISION IN ACTION
            </p>
            <h1>
              Building hope.
              <br />
              <em>Together.</em>
            </h1>
            <p>
              Every project represents an opportunity to serve people, grow the
              church and build something that lasts beyond us.
            </p>
            <Link href="#explore" className="btn btn--white">
              Explore the vision <span>↓</span>
            </Link>
          </div>
          <div className="projects-hero__photo" data-reveal="">
            <Image
              src="/media/v5/photo4.jpg"
              alt="Community outreach — illustrative photo, not our church"
              width={1600}
              height={1067}
              sizes="(max-width: 760px) 100vw, 45vw"
            />
            <span>THE VISION / IN ACTION</span>
          </div>
        </div>
        <div className="projects-hero__number">01 / KINGDOM</div>
      </section>
      <section className="projects-directory section-pad" id="explore">
        <div className="wrap">
          <div className="section-heading" data-reveal="">
            <div>
              <p className="kicker">
                <span className="kicker__bar" />
                PROJECTS &amp; INITIATIVES
              </p>
              <h2>
                Faith in action.
                <br />
                <em>Love in motion.</em>
              </h2>
            </div>
            <p>
              Browse the sample project experience below. Project names, plans
              and progress will be replaced with church-approved information.
            </p>
          </div>
          <div className="project-grid">
            {projects.map((project, index) => (
              <ProjectCard key={project.slug} project={project} index={index} />
            ))}
          </div>
          <p className="project-grid__notice">
            These project examples are for design demonstration only. No real
            fundraising information, current projects or transactions are being
            claimed.
          </p>
        </div>
      </section>
      <section className="impact-band section-pad">
        <div className="wrap impact-band__inner" data-reveal="">
          <p className="kicker kicker--light">
            <span className="kicker__bar" />
            TRANSPARENCY MATTERS
          </p>
          <h2>
            Every contribution
            <br />
            <em>deserves clarity.</em>
          </h2>
          <p>
            When launched, verified progress, project updates and secure giving
            options will help supporters understand the impact of their
            partnership.
          </p>
          <Link
            className="btn btn--red"
            href="/projects/building-for-generations"
          >
            Preview the giving journey <span>↗</span>
          </Link>
        </div>
      </section>
    </main>
  );
}
