import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { SiteExperience } from "@/components/site-experience";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
const dmSans = localFont({
  src: "./fonts/dm-sans-latin.woff2",
  variable: "--font-dm-sans",
  display: "swap",
  weight: "100 900",
});
export const metadata: Metadata = {
  title: "RCCG Spring of Life | A place to belong · Abuja",
  description:
    "Growing in faith. Connected in love. Living with purpose. Welcome to RCCG Spring of Life, Abuja — there’s a place for you in our family.",
  robots: { index: false, follow: false },
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en-NG" className={dmSans.variable}>
      <body>
        <SiteExperience>
          <SiteHeader />
          {children}
          <SiteFooter />
        </SiteExperience>
      </body>
    </html>
  );
}
