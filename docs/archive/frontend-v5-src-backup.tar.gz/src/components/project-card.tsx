import Image from "next/image";
import Link from "next/link";
import type { Project } from "@/data/projects";
export function ProjectCard({
  project,
  index,
}: {
  project: Project;
  index: number;
}) {
  return (
    <article className="project-card" data-reveal="">
      <Link href={`/projects/${project.slug}`}>
        <div className="project-card__photo">
          <Image
            src={project.image}
            width={1600}
            height={1067}
            sizes="(max-width: 760px) 100vw, 33vw"
            alt={`${project.category.toLowerCase()} — illustrative photo, not our church`}
          />
          <span>
            0{index + 1} / {project.category}
          </span>
        </div>
        <div className="project-card__body">
          <h3>{project.title}</h3>
          <p>{project.description}</p>
          <div className="project-card__progress">
            <span className="project-card__track" aria-hidden="true" />
            <small>Funding target &amp; progress awaiting verification</small>
          </div>
          <strong>Explore project ↗</strong>
        </div>
      </Link>
    </article>
  );
}
