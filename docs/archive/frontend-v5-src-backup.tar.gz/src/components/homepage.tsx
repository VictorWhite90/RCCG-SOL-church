import { Hero } from "./hero";
import {
  QuickLinks,
  Introduction,
  Gatherings,
  FaithRibbon,
  Messages,
  Ministries,
  KingdomProjects,
  Testimonies,
  Visit,
} from "./home-sections";
export function Homepage() {
  return (
    <main id="main">
      <Hero />
      <QuickLinks />
      <Introduction />
      <Gatherings />
      <FaithRibbon />
      <Messages />
      <Ministries />
      <KingdomProjects />
      <Testimonies />
      <Visit />
    </main>
  );
}
