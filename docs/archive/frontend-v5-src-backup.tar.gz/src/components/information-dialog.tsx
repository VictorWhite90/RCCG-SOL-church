"use client";
import { useEffect, useRef } from "react";
import { X } from "lucide-react";
import { information, type InformationKey } from "@/data/church";

export function InformationDialog({
  active,
  onClose,
}: {
  active: InformationKey | null;
  onClose: () => void;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    if (!active) return;
    const previousOverflow = document.body.style.overflow;
    const dialog = ref.current;
    dialog?.showModal();
    document.body.style.overflow = "hidden";
    return () => {
      dialog?.close();
      document.body.style.overflow = previousOverflow;
    };
  }, [active]);
  const content = active ? information[active] : null;
  return (
    <dialog
      ref={ref}
      className="information-dialog"
      aria-labelledby="dialog-title"
      aria-describedby="dialog-description"
      onCancel={onClose}
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      {content && (
        <div className="dialog-content">
          <button
            autoFocus
            className="dialog-close"
            aria-label="Close information"
            onClick={onClose}
          >
            <X size={22} />
          </button>
          <p className="eyebrow">{content.eyebrow}</p>
          <h2 id="dialog-title">{content.title}</h2>
          <p id="dialog-description">{content.description}</p>
          <div className="availability">
            <span className="status-dot" />
            Details being prepared
          </div>
          <p className="dialog-detail">{content.detail}</p>
          <button className="button button-navy" onClick={onClose}>
            Back to the homepage
          </button>
        </div>
      )}
    </dialog>
  );
}
