"use client";
import Link from "next/link";
import { Pause, Play } from "lucide-react";
import { church } from "@/data/church";
import { useHeroVideo } from "@/hooks/use-hero-video";
export function Hero() {
  const { video, playing, failed, toggle } = useHeroVideo();
  return (
    <section className="hero" id="home" aria-labelledby="hero-heading">
      <div className="hero__media" aria-hidden="true">
        <video
          ref={video}
          muted
          loop
          playsInline
          preload="none"
          poster={church.hero.poster}
          tabIndex={-1}
        />
      </div>
      <div className="hero__veil" />
      <div className="hero__grid" />
      <div className="hero__content wrap">
        <div data-hero-detail className="hero__eyebrow">
          <span className="pulse" /> THE REDEEMED CHRISTIAN CHURCH OF GOD •
          ABUJA
        </div>
        <p data-hero-detail className="hero__small">
          THERE&apos;S A PLACE FOR YOU
        </p>
        <h1 id="hero-heading">
          {church.hero.lines.map((line, index) => (
            <span
              key={line}
              data-hero-line
              style={{
                display: "block",
                color: index === 1 ? "#e1e8f4" : "white",
              }}
            >
              {line}{" "}
            </span>
          ))}
        </h1>
        <p data-hero-detail className="hero__sub">
          {church.hero.introduction}
        </p>
        <div data-hero-detail className="hero__actions">
          <Link className="btn btn--red" href="#visit">
            Join us this Sunday <span>↗</span>
          </Link>
          <Link className="btn btn--outline" href="#sermons">
            Experience a service <span>↗</span>
          </Link>
        </div>
      </div>
      <div className="hero__bottom wrap">
        <Link href="#about" className="hero__scroll">
          <span className="scroll-line" /> SCROLL TO DISCOVER
        </Link>
        <div className="hero__media-controls">
          <span className="media-badge">
            ILLUSTRATIVE SLIDESHOW · NOT OUR CHURCH
          </span>
          <button
            type="button"
            className="circle-control"
            onClick={toggle}
            disabled={failed}
            aria-label={
              failed
                ? "Background video unavailable"
                : playing
                  ? "Pause background video"
                  : "Play background video"
            }
          >
            {playing ? <Pause size={14} /> : <Play size={14} />}
          </button>
        </div>
      </div>
      <div className="hero__index">01 / 07</div>
      <span className="mobile-media-notice">
        Illustrative slideshow · not our church
      </span>
    </section>
  );
}
