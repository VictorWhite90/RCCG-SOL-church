import Image from "next/image";
import { ministries } from "@/data/home-content";
import { InformationButton } from "../site-experience";

export function Ministries() {
  return (
    <section className="ministries section-pad" id="ministries">
      <div className="wrap">
        <div className="section-heading" data-reveal="">
          <div>
            <p className="kicker">
              <span className="kicker__bar"></span> 04 / FIND YOUR PLACE
            </p>
            <h2>
              Life is better
              <br /> <em>together.</em>
            </h2>
          </div>
          <p>
            Different stories. One family. Find a place to grow, belong, and
            serve with others.
          </p>
        </div>
        <div className="ministry-carousel" id="ministryCarousel">
          {ministries.map((ministry, index) => (
            <article
              key={ministry.category}
              className="ministry-card"
              data-reveal=""
            >
              <InformationButton
                kind="ministries"
                className="ministry-card__action"
              >
                <Image
                  src={ministry.image}
                  alt={ministry.alt}
                  width={1600}
                  height={1067}
                  sizes="(max-width: 760px) 85vw, 33vw"
                />
                <div className="ministry-card__content">
                  <span>
                    0{index + 1} / {ministry.category}
                  </span>
                  <h3>{ministry.title}</h3>
                  <span>{ministry.action} ↗</span>
                </div>
              </InformationButton>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
