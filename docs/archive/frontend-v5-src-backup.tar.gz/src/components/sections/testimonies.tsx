import Image from "next/image";
import { InformationButton } from "../site-experience";

export function Testimonies() {
  return (
    <section className="testimonies section-pad" id="testimonies">
      <div className="wrap testimonials__grid">
        <div data-reveal="">
          <p className="kicker">
            <span className="kicker__bar"></span> 06 / STORIES OF GRACE
          </p>
          <h2>
            Every story
            <br /> <em>matters.</em>
          </h2>
          <p className="body-lg">
            Faith takes shape in everyday lives. Here, we will celebrate real
            testimonies shared with permission by members of our church family.
          </p>
          <InformationButton kind="stories" className="text-link">
            Share your story <span>↗</span>
          </InformationButton>
        </div>
        <div className="testimonials__photo" data-reveal="">
          <Image
            src="/media/v5/photo1.jpg"
            loading="lazy"
            alt="Friends warmly connecting (illustrative church community image)"
            width={1600}
            height={1067}
            sizes="(max-width: 760px) 100vw, 50vw"
          />
          <div className="testimonials__caption">
            <span>STORIES OF GRACE</span>
            <strong>God is writing stories.</strong>
            <small>Approved testimonies coming soon.</small>
          </div>
        </div>
      </div>
    </section>
  );
}
