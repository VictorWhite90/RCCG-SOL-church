import Link from "next/link";
import { InformationButton } from "../site-experience";

export function QuickLinks() {
  return (
    <section className="ribbon" aria-label="Quick links">
      <div className="wrap ribbon__inner">
        <Link href="#visit">
          <span className="ribbon__index">01 — FIRST TIME?</span>
          <strong>We saved you a seat</strong>
          <span>↗</span>
        </Link>
        <Link href="#sermons">
          <span className="ribbon__index">02 — JOIN FROM ANYWHERE</span>
          <strong>Worship with us online</strong>
          <span>↗</span>
        </Link>
        <InformationButton kind="prayer">
          <span className="ribbon__index">03 — NEED PRAYER?</span>
          <strong>We&apos;re here for you</strong>
          <span>↗</span>
        </InformationButton>
      </div>
    </section>
  );
}
