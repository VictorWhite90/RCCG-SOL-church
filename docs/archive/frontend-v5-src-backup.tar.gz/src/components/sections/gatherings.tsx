import Image from "next/image";

export function Gatherings() {
  return (
    <section className="events section-pad" id="events">
      <div className="wrap">
        <div className="section-heading" data-reveal="">
          <div>
            <p className="kicker">
              <span className="kicker__bar"></span> 02 / LIFE AT SPRING OF LIFE
            </p>
            <h2>
              There&apos;s always
              <br /> <em>something happening.</em>
            </h2>
          </div>
          <p>
            From Sundays to the moments in between, there&apos;s a place to
            gather, connect and grow.
          </p>
        </div>
        <div className="events__layout">
          <article className="event-feature" data-reveal="">
            <div className="image-zoom">
              <Image
                src="/media/v5/photo2.jpg"
                loading="lazy"
                alt="Preacher and choir at worship (illustrative image)"
                width={1600}
                height={1067}
                sizes="(max-width: 760px) 100vw, 50vw"
              />
            </div>
            <div className="event-feature__overlay">
              <span className="tag tag--light">WORSHIP & THE WORD</span>
              <h3>
                More than
                <br /> a Sunday.
              </h3>
              <div className="event-feature__foot">
                <span>Join the family this week</span>
                <span className="arrow-circle">↗</span>
              </div>
            </div>
          </article>
          <div className="events__side">
            <article className="event-row" data-reveal="">
              <div className="event-row__image">
                <Image
                  src="/media/v5/photo3.jpg"
                  loading="lazy"
                  alt="Community food distribution (illustrative image)"
                  width={1600}
                  height={1067}
                  sizes="(max-width: 760px) 100vw, 50vw"
                />
              </div>
              <div className="event-row__info">
                <span className="label">CONNECT & GROW</span>
                <h3>
                  Find your
                  <br /> community
                </h3>
                <p>Faith gets stronger together.</p>
                <span className="arrow-small">↗</span>
              </div>
            </article>
            <article className="event-row" data-reveal="">
              <div className="event-row__image">
                <Image
                  src="/media/v5/photo5.jpg"
                  loading="lazy"
                  alt="Volunteers serving the community (illustrative image)"
                  width={1600}
                  height={1067}
                  sizes="(max-width: 760px) 100vw, 50vw"
                />
              </div>
              <div className="event-row__info">
                <span className="label">SERVE WITH PURPOSE</span>
                <h3>
                  Make a<br /> difference
                </h3>
                <p>There&apos;s a place for your gifts.</p>
                <span className="arrow-small">↗</span>
              </div>
            </article>
          </div>
        </div>
        <p className="events__note">
          Programme names and times will be updated with confirmed church
          information.
        </p>
      </div>
    </section>
  );
}
