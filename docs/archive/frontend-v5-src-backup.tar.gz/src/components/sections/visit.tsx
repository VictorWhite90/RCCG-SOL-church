import { InformationButton } from "../site-experience";

export function Visit() {
  return (
    <section className="visit section-pad" id="visit">
      <div className="wrap visit__inner" data-reveal="">
        <span className="kicker">07 / THIS IS YOUR INVITATION</span>
        <h2>
          There&apos;s a place
          <br /> for <em>you</em> here.
        </h2>
        <p>
          Whether it&apos;s your first Sunday or you&apos;ve been looking for a
          church family, we&apos;d love to welcome you.
        </p>
        <InformationButton kind="visit" className="btn btn--dark">
          Plan your visit <span>↗</span>
        </InformationButton>
        <span className="visit__note">
          Service times, address and visitor contact are awaiting confirmation.
        </span>
      </div>
    </section>
  );
}
