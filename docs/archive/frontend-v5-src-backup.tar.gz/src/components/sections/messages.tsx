import Image from "next/image";
import { InformationButton } from "../site-experience";

export function Messages() {
  return (
    <section className="sermons section-pad" id="sermons">
      <div className="wrap sermons__grid">
        <div className="sermons__text" data-reveal="">
          <p className="kicker kicker--light">
            <span className="kicker__bar"></span> 03 / RECENT MESSAGES
          </p>
          <h2>
            Truth for
            <br /> <em>the everyday.</em>
          </h2>
          <p>
            Messages that equip, encourage and draw us closer to God. Find
            something for the season you&apos;re in.
          </p>
          <InformationButton kind="sermons" className="btn btn--white">
            Explore messages <span>↗</span>
          </InformationButton>
        </div>
        <div className="sermons__image" data-reveal="">
          <Image
            src="/media/v5/photo2.jpg"
            loading="lazy"
            alt="Preaching and worship at a church gathering (illustrative image)"
            width={1600}
            height={1067}
            sizes="(max-width: 760px) 100vw, 50vw"
          />
          <InformationButton kind="sermons" className="sermons__play">
            <span aria-hidden="true">▶</span>
            <span className="sr-only">View message availability</span>
          </InformationButton>
          <span className="sermons__overlay-label">
            LATEST MESSAGE · COMING SOON
          </span>
        </div>
      </div>
    </section>
  );
}
