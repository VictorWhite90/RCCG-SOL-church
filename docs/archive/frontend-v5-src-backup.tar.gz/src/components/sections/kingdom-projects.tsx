import Image from "next/image";
import Link from "next/link";

export function KingdomProjects() {
  return (
    <section className="projects section-pad" id="projects">
      <div className="projects__backdrop" aria-hidden="true">
        IMPACT
      </div>
      <div className="wrap">
        <div className="projects__top" data-reveal="">
          <div>
            <p className="kicker kicker--light">
              <span className="kicker__bar"></span> 05 / KINGDOM PROJECTS
            </p>
            <h2>
              What we build
              <br /> <em>outlives us.</em>
            </h2>
          </div>
          <p>
            Partner with the vision. Support projects that strengthen our
            church, serve our city and create lasting impact.
          </p>
        </div>
        <div className="projects__cards">
          <article className="project-main" data-reveal="">
            <div className="project-main__image">
              <Image
                src="/media/v5/photo3.jpg"
                loading="lazy"
                alt="Community outreach and food distribution (illustrative image)"
                width={1600}
                height={1067}
                sizes="(max-width: 760px) 100vw, 50vw"
              />
              <span className="tag tag--light">FEATURED PROJECT</span>
            </div>
            <div className="project-main__body">
              <span className="label">COMMUNITY IMPACT / ILLUSTRATIVE</span>
              <h3>
                Love, beyond
                <br /> the walls.
              </h3>
              <p>
                Community outreach and practical care. Final church-approved
                project details will appear here.
              </p>
              <div className="project-main__meta">
                <span>
                  Funding goal <strong>To be confirmed</strong>
                </span>
                <span>
                  Status <strong>Awaiting approval</strong>
                </span>
              </div>
              <Link
                href="/projects/love-beyond-the-walls"
                className="btn btn--red"
              >
                Explore this vision <span>↗</span>
              </Link>
            </div>
          </article>
          <div className="project-aside" data-reveal="">
            <span className="project-aside__number">01 /</span>
            <h3>
              Every gift.
              <br /> Every step.
              <br /> <em>Every life.</em>
            </h3>
            <p>
              A transparent place to explore approved projects, read updates and
              support them securely via Paystack after launch.
            </p>
            <div className="project-aside__line"></div>
            <Link className="project-aside__link" href="/projects">
              SEE ALL KINGDOM PROJECTS ↗
            </Link>
          </div>
        </div>
        <p className="projects__disclaimer">
          Demo project imagery and descriptions are illustrative. No actual
          fundraising totals or live payments are displayed.
        </p>
      </div>
    </section>
  );
}
