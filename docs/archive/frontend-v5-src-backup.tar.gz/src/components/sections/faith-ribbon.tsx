export function FaithRibbon() {
  return (
    <section className="marquee" aria-hidden="true">
      <div className="marquee__track">
        FAITH IN ACTION <span>✳</span> LOVE IN MOTION <span>✳</span> A PLACE TO
        BELONG <span>✳</span> FAITH IN ACTION <span>✳</span> LOVE IN MOTION{" "}
        <span>✳</span> A PLACE TO BELONG <span>✳</span>
      </div>
    </section>
  );
}
