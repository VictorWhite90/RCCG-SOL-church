import Image from "next/image";
import Link from "next/link";

export function Introduction() {
  return (
    <section className="intro section-pad" id="about">
      <div className="wrap intro__layout">
        <div className="intro__copy" data-reveal="">
          <p className="kicker">
            <span className="kicker__bar"></span> 01 / THE HEART OF OUR CHURCH
          </p>
          <h2>
            Faith is a journey.
            <br /> <em>Not a solo one.</em>
          </h2>
          <p className="body-lg">
            This is more than a place you attend. It&apos;s a family you grow
            with, a community you serve alongside, and a place to discover more
            of God&apos;s purpose for your life.
          </p>
          <Link className="text-link" href="#connect">
            Get to know us <span>↗</span>
          </Link>
          <div className="intro__micro">
            GROWING IN THE WORD <span>✳</span> GROUNDED IN LOVE <span>✳</span>{" "}
            LIVING ON MISSION
          </div>
        </div>
        <div className="intro__visual" data-reveal="">
          <div className="photo-mat photo-mat--portrait">
            <Image
              src="/media/v5/photo1.jpg"
              loading="lazy"
              alt="Church friends warmly greeting each other (illustrative image)"
              width={1600}
              height={1067}
              sizes="(max-width: 760px) 100vw, 50vw"
            />
          </div>
          <div className="intro__caption">
            <span>TOGETHER</span>
            <span>WE BELONG.</span>
          </div>
          <div className="intro__red-square" aria-hidden="true">
            ✳
          </div>
        </div>
      </div>
    </section>
  );
}
