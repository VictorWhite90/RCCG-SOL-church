"use client";
import {
  createContext,
  useContext,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { useHeroMotion } from "@/hooks/use-hero-motion";
import { InformationDialog } from "./information-dialog";
import type { InformationKey } from "@/data/church";
const InformationContext = createContext<(key: InformationKey) => void>(
  () => {},
);
export function SiteExperience({ children }: { children: ReactNode }) {
  const root = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState<InformationKey | null>(null);
  useHeroMotion(root);
  return (
    <InformationContext.Provider value={setActive}>
      <div ref={root}>
        <a className="skip" href="#main">
          Skip to content
        </a>
        <div className="curtain" aria-hidden="true">
          <div className="curtain__left" data-curtain-left>
            <span>SPRING</span>
          </div>
          <div className="curtain__right" data-curtain-right>
            <span>OF LIFE.</span>
          </div>
        </div>
        {children}
        <InformationDialog active={active} onClose={() => setActive(null)} />
      </div>
    </InformationContext.Provider>
  );
}
export function InformationButton({
  kind,
  className,
  children,
}: {
  kind: InformationKey;
  className?: string;
  children: ReactNode;
}) {
  const open = useContext(InformationContext);
  return (
    <button type="button" className={className} onClick={() => open(kind)}>
      {children}
    </button>
  );
}
