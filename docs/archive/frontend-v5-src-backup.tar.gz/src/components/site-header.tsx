"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
const links = [
  { href: "/#about", label: "Our church" },
  { href: "/#events", label: "Gatherings" },
  { href: "/#sermons", label: "Messages" },
  { href: "/#ministries", label: "Ministries" },
  { href: "/projects", label: "Kingdom projects" },
];
export function SiteHeader() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const toggle = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    const update = () => setScrolled(window.scrollY > 95);
    update();
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, []);
  return (
    <header
      className={`site-header ${pathname !== "/" || scrolled ? "is-sticky" : ""}`}
    >
      <Link className="identity" href="/" aria-label="Spring of Life home">
        <span className="identity__symbol">
          S<span className="identity__star">✳</span>L
        </span>
        <span className="identity__name">
          SPRING<span>OF LIFE</span>
          <small>RCCG • ABUJA</small>
        </span>
      </Link>
      <nav
        id="navigation"
        className={`nav ${open ? "is-open" : ""}`}
        aria-label="Main navigation"
        onKeyDown={(event) => {
          if (event.key === "Escape") {
            setOpen(false);
            toggle.current?.focus();
          }
        }}
      >
        {links.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            aria-current={
              link.href === "/projects" && pathname.startsWith("/projects")
                ? "page"
                : undefined
            }
            onClick={() => setOpen(false)}
          >
            {link.label}
          </Link>
        ))}
      </nav>
      <Link href="/#visit" className="header-cta">
        Plan a visit <span>↗</span>
      </Link>
      <button
        ref={toggle}
        className="menu-toggle"
        aria-controls="navigation"
        aria-expanded={open}
        aria-label={open ? "Close navigation" : "Open navigation"}
        onClick={() => setOpen(!open)}
      >
        <span />
        <span />
      </button>
    </header>
  );
}
