"use client";
import { useRef, useState } from "react";
const amounts = [5000, 10000, 25000] as const;
export function ContributionPreview() {
  const [amount, setAmount] = useState("10000");
  const [custom, setCustom] = useState(false);
  const [status, setStatus] = useState("");
  const input = useRef<HTMLInputElement>(null);
  function preview() {
    const value = Number(amount);
    setStatus(
      Number.isFinite(value) &&
        value >= 100 &&
        value <= 100000000 &&
        Number.isInteger(value)
        ? `This is a design-only preview for ₦${value.toLocaleString("en-NG")}. Payment processing is not enabled.`
        : "Please enter a whole-naira amount between ₦100 and ₦100,000,000.",
    );
  }
  return (
    <aside className="giving-panel" data-reveal="">
      <span className="label">GIVE TOWARDS THE VISION</span>
      <h2>
        Every gift
        <br />
        makes a difference.
      </h2>
      <p>
        Donation checkout will be enabled only after the church has approved its
        project details and Paystack account.
      </p>
      <div className="giving-panel__totals">
        <div>
          <span>Funding goal</span>
          <strong>Not published</strong>
        </div>
        <div>
          <span>Verified progress</span>
          <strong>Not published</strong>
        </div>
      </div>
      <label className="giving-label" htmlFor="givingAmount">
        Choose a contribution (demo)
      </label>
      <div
        className="amount-grid"
        role="group"
        aria-label="Choose a demo donation amount"
      >
        {amounts.map((value) => (
          <button
            type="button"
            key={value}
            aria-pressed={!custom && amount === String(value)}
            onClick={() => {
              setCustom(false);
              setAmount(String(value));
              setStatus("");
            }}
          >
            ₦{value.toLocaleString("en-NG")}
          </button>
        ))}
        <button
          type="button"
          aria-pressed={custom}
          onClick={() => {
            setCustom(true);
            input.current?.focus();
            input.current?.select();
          }}
        >
          Other
        </button>
      </div>
      <label className="sr-only" htmlFor="givingAmount">
        Demo contribution amount in naira
      </label>
      <input
        ref={input}
        id="givingAmount"
        type="number"
        min="100"
        max="100000000"
        step="1"
        inputMode="numeric"
        value={amount}
        aria-describedby="givingInfo"
        onChange={(event) => {
          setAmount(event.target.value);
          setCustom(true);
          setStatus("");
        }}
      />
      <p id="givingInfo" className="giving-panel__info">
        Preview only. No payments will be collected.
      </p>
      <button
        className="btn btn--red giving-submit"
        type="button"
        onClick={preview}
      >
        PREVIEW SUPPORT FLOW <span>↗</span>
      </button>
      <p className="giving-panel__safe">
        Paystack integration is planned for a later phase. This preview never
        collects card details or sends a payment request.
      </p>
      <output aria-live="polite">{status}</output>
    </aside>
  );
}
