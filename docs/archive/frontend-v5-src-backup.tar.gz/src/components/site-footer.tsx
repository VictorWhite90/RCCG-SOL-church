import Link from "next/link";
export function SiteFooter() {
  return (
    <footer className="footer" id="connect">
      <div className="wrap">
        <div className="footer__top">
          <div>
            <Link className="footer__brand" href="/">
              SPRING
              <br /> OF LIFE<span>✳</span>
            </Link>
            <p>Growing in faith. Connected in love. Living with purpose.</p>
          </div>
          <div className="footer__links">
            <div>
              <span>EXPLORE</span>
              <Link href="/#about">Our church</Link>
              <Link href="/#events">Gatherings</Link>
              <Link href="/#sermons">Messages</Link>
            </div>
            <div>
              <span>CONNECT</span>
              <Link href="/#ministries">Ministries</Link>
              <Link href="/projects">Kingdom projects</Link>
              <Link href="/#visit">Plan your visit</Link>
            </div>
          </div>
        </div>
        <div className="footer__bottom">
          <span>© 2026 RCCG SPRING OF LIFE · ABUJA</span>
          <span>DESIGN PROTOTYPE · NOT THE OFFICIAL LIVE CHURCH WEBSITE</span>
          <Link href="/">BACK TO TOP ↑</Link>
        </div>
      </div>
    </footer>
  );
}
