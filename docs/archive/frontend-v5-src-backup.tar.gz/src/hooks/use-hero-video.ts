"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { church } from "@/data/church";

type Connection = EventTarget & { saveData?: boolean; effectiveType?: string };
function connection() {
  return (navigator as Navigator & { connection?: Connection }).connection;
}
function shouldSaveData() {
  const network = connection();
  return (
    network?.saveData ||
    ["slow-2g", "2g"].includes(network?.effectiveType ?? "")
  );
}

export function useHeroVideo() {
  const video = useRef<HTMLVideoElement>(null);
  const userPaused = useRef(false);
  const [playing, setPlaying] = useState(false);
  const [failed, setFailed] = useState(false);
  const load = useCallback(() => {
    const element = video.current;
    if (!element || element.querySelector("source")) return;
    church.hero.sources.forEach(({ src, type }) => {
      const source = document.createElement("source");
      source.src = src;
      source.type = type;
      element.append(source);
    });
    element.load();
  }, []);
  const play = useCallback(() => {
    load();
    void video.current?.play().catch(() => setPlaying(false));
  }, [load]);
  useEffect(() => {
    const element = video.current;
    if (!element) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)");
    const network = connection();
    let visible = true;
    const allowed = () =>
      !reduced.matches &&
      !shouldSaveData() &&
      !userPaused.current &&
      !document.hidden &&
      visible;
    const update = () => {
      if (allowed()) play();
      else element.pause();
    };
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onError = () => {
      setFailed(true);
      setPlaying(false);
    };
    element.addEventListener("play", onPlay);
    element.addEventListener("pause", onPause);
    element.addEventListener("error", onError);
    reduced.addEventListener("change", update);
    network?.addEventListener("change", update);
    document.addEventListener("visibilitychange", update);
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      update();
    });
    observer.observe(element);
    update();
    return () => {
      observer.disconnect();
      element.pause();
      element.removeEventListener("play", onPlay);
      element.removeEventListener("pause", onPause);
      element.removeEventListener("error", onError);
      reduced.removeEventListener("change", update);
      network?.removeEventListener("change", update);
      document.removeEventListener("visibilitychange", update);
    };
  }, [play]);
  const toggle = () => {
    if (playing) {
      userPaused.current = true;
      video.current?.pause();
    } else {
      userPaused.current = false;
      play();
    }
  };
  return { video, playing, failed, toggle };
}
