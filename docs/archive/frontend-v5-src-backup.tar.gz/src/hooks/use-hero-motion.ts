"use client";
import { useEffect, type RefObject } from "react";
import { usePathname } from "next/navigation";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
export function useHeroMotion(root: RefObject<HTMLElement | null>) {
  const pathname = usePathname();
  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const media = gsap.matchMedia();
    media.add("(prefers-reduced-motion: no-preference)", () => {
      const context = gsap.context(() => {
        gsap
          .timeline({ defaults: { ease: "power3.out" } })
          .fromTo(
            "[data-curtain-left]",
            { xPercent: 0, x: 0 },
            {
              xPercent: -101,
              delay: 0.15,
              duration: 1.05,
              ease: "power4.inOut",
            },
            0,
          )
          .fromTo(
            "[data-curtain-right]",
            { xPercent: 0, x: 0 },
            {
              xPercent: 101,
              delay: 0.15,
              duration: 1.05,
              ease: "power4.inOut",
            },
            0,
          )
          .from(
            "[data-hero-line]",
            { y: 30, opacity: 0, duration: 0.8, stagger: 0.1 },
            "-=0.35",
          )
          .from(
            "[data-hero-detail]",
            { y: 18, opacity: 0, duration: 0.6, stagger: 0.1 },
            "-=0.4",
          );
        gsap.utils.toArray<HTMLElement>("[data-reveal]").forEach((element) => {
          gsap.from(element, {
            y: 35,
            opacity: 0,
            duration: 0.85,
            scrollTrigger: { trigger: element, start: "top 94%", once: true },
          });
        });
      }, root);
      return () => context.revert();
    });
    return () => media.revert();
  }, [root, pathname]);
}
