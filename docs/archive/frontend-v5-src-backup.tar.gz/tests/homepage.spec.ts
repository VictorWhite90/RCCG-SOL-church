import { expect, test } from "@playwright/test";

test("updated homepage renders all sections, plays film and opens verified-content dialogs", async ({ page }, testInfo) => {
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("Come as you are. Become who you’re called to be.");
  await expect(page.getByRole("button", { name: "Pause background video" })).toBeVisible();
  await page.getByRole("button", { name: "Pause background video" }).click();
  await expect(page.locator("video")).toHaveJSProperty("paused", true);
  await page.getByRole("button", { name: "Play background video" }).click();
  await expect(page.locator("video")).toHaveJSProperty("paused", false);
  for (const id of ["about", "events", "sermons", "ministries", "projects", "testimonies", "visit"]) {
    await page.locator(`#${id}`).scrollIntoViewIfNeeded();
    await expect(page.locator(`#${id}`)).toBeVisible();
  }
  const visit = page.getByRole("button", { name: /^Plan your visit/ });
  await visit.click();
  await expect(page.getByRole("dialog")).toContainText("confirmed service times");
  await page.keyboard.press("Escape");
  await expect(visit).toBeFocused();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.evaluate(() => scrollTo({ top: 0, behavior: "instant" }));
  await expect(page.locator("[data-hero-line]").last()).toHaveCSS("opacity", "1");
  await page.screenshot({ path: `../docs/v5-home-${testInfo.project.name}.png`, fullPage: true, scale: "css" });
  expect(errors).toEqual([]);
});

test("motion and network preferences prevent automatic video downloads", async ({ page }) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  const requests: string[] = [];
  page.on("request", request => { if (request.url().endsWith("hero-demo.mp4")) requests.push(request.url()); });
  await page.goto("/");
  await expect(page.getByRole("button", { name: "Play background video" })).toBeVisible();
  await expect(page.locator("video source")).toHaveCount(0);
  expect(requests).toEqual([]);
  await page.emulateMedia({ reducedMotion: "no-preference" });
  await expect(page.getByRole("button", { name: "Pause background video" })).toBeVisible();
  await page.addInitScript(() => Object.defineProperty(navigator, "connection", { value: { saveData: true, addEventListener() {}, removeEventListener() {} }, configurable: true }));
  requests.length = 0;
  await page.reload();
  await expect(page.locator("video source")).toHaveCount(0);
  expect(requests).toEqual([]);
  await page.getByRole("button", { name: "Play background video" }).click();
  await expect(page.getByRole("button", { name: "Pause background video" })).toBeVisible();
});

test("project listing and individual details keep giving local and non-transactional", async ({ page }, testInfo) => {
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.goto("/projects");
  await expect(page.locator(".project-card")).toHaveCount(3);
  await page.getByRole("link", { name: /02 \/ COMMUNITY OUTREACH/ }).click();
  await expect(page).toHaveURL(/\/projects\/love-beyond-the-walls$/);
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("Love beyond the walls");
  await page.getByRole("button", { name: "₦25,000", exact: true }).click();
  await expect(page.getByRole("button", { name: "₦25,000", exact: true })).toHaveAttribute("aria-pressed", "true");
  await page.getByRole("button", { name: "PREVIEW SUPPORT FLOW" }).click();
  await expect(page.locator("output")).toContainText("design-only preview for ₦25,000");
  await page.getByLabel("Demo contribution amount in naira").fill("-1");
  await page.getByRole("button", { name: "PREVIEW SUPPORT FLOW" }).click();
  await expect(page.locator("output")).toContainText("Please enter");
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.evaluate(() => { (document.activeElement as HTMLElement)?.blur(); scrollTo({ top: 0, behavior: "instant" }); });
  await page.screenshot({ path: `../docs/v5-project-${testInfo.project.name}.png`, fullPage: true, scale: "css" });
  await page.goto("/projects/building-for-generations");
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("Building for generations");
  await page.goto("/projects/making-room-for-the-message");
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("Making room for the message");
  await page.goto("/projects/not-a-project");
  await expect(page.getByRole("heading", { name: "404" })).toBeVisible();
  expect(errors).toEqual([]);
});

test("mobile navigation routes to real sections and projects", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "mobile");
  await page.goto("/");
  await page.getByRole("button", { name: "Open navigation" }).click();
  await page.getByRole("navigation", { name: "Main navigation" }).getByRole("link", { name: "Kingdom projects" }).click();
  await expect(page).toHaveURL(/\/projects$/);
  await expect(page.getByRole("button", { name: "Open navigation" })).toHaveAttribute("aria-expanded", "false");
});
