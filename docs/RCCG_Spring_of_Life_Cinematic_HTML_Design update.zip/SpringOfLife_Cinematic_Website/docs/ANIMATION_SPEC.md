# Motion and media spec

## Hero
- 10–15 seconds, silent video is recommended, with autoplay + muted + loop + playsinline, actual playback dependent on browser rules.
- Encode MP4 (H.264), plus WebM where helpful. Use a static WebP poster for first paint and disabled-motion/data-saving contexts.
- Avoid captions or factual church branding burned into footage until verified.
- Test 3G/mobile scenarios and low-end devices; poster must look good without video.

## Curtain
- Two editorial full-height panels open horizontally.
- Keep it brief and allow content to remain accessible. Disable animation for reduced-motion preference.

## Section transitions
- IntersectionObserver-based vertical reveal with no library needed in this demo.
- On actual Next.js site, can implement more precise choreography with GSAP ScrollTrigger, disposing timelines on unmount.

## Giving
- No actual checkout in this preview. Express backend should create/verify Paystack transactions, use webhook signature verification, idempotent transaction processing, role-restricted reporting, and a clearly published contribution policy.
