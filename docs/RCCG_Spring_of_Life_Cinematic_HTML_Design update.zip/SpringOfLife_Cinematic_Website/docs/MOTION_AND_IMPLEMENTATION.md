# Motion and interaction handoff — updated V5

| Effect | Trigger | Duration | Detail |
| --- | --- | --- | --- |
| Curtain reveal | Initial page load | ~1.05s + 400ms delay | Navy and red panels move outward; disabled for prefers-reduced-motion |
| Hero background | Automatic if allowed | 12-second illustrative loop | Muted, playsInline, looping; static photo fallback; skip on save-data or reduced motion; pause/resume button |
| Text/image reveals | Sections enter viewport | ~900ms | Opacity + translateY, IntersectionObserver; no scroll-jacking |
| Photo hover | Pointer hover | ~700–1000ms | Crop-safe scale within photo containers |
| Navigation | Hamburger click | Immediate | Mobile menu with aria-expanded |
| Kingdom cards | Pointer hover/focus | ~350ms | Elevated cards and zoomed photos; respects reduced motion |
| Contribution amounts | Select button | Immediate | Changes **demo-only** amount. Support button displays message but never opens checkout |

## Planned next work
- Swap illustrations for copyright-cleared approved church videos and photographs.
- Build actual Figma prototype links where supported; Figma Starter rate limit prevented connecting Smart Animate state frames during this iteration.
- Replace demo static image slideshow with a short, compressed live-action church clip once approved.
- Add server-backed events, sermon metadata, content moderation and prayer handling via Express.js.
- Confirm Paystack merchant ownership, webhook signature verification, idempotency, transaction records and official giving language before activation.
