# RCCG Spring of Life Abuja — Updated Cinematic HTML UI (V5)

This is a **visual prototype**, not the official live church website. Open `index.html` to start. All images and the video are illustrative demo assets, not documented real church events.

## Files and pages
- `index.html` — complete responsive homepage, full-screen video hero, animated curtain, worship, events, sermons, ministries, Kingdom Projects teaser, testimonials, invitation, footer.
- `projects.html` — full Kingdom Projects listing with 3 illustrative projects, image-led cards and unfunded placeholder progress tracks.
- `project-detail.html` — project story, milestone layout, donation UI mock with interactive amount selection and no live checkout.
- `styles.css` — the full visual system, responsive rules, hover animation, page transitions, curtain reveal and image/scroll effects.
- `script.js` — video accessibility/data-saving behaviour, reveal observer, mobile navigation and non-transactional demo giving interactions.
- `assets/` — demo imagery and a short compressed silent video slideshow for illustrating the hero (not filmed church footage).
- `docs/MOTION_AND_IMPLEMENTATION.md` — motion storyboard and handoff.

## Preview
Unzip and double click `index.html`. All pages link together. If your browser restricts video from file URLs, use a local server: open a terminal in this folder and run `python -m http.server 8080`, then browse `http://localhost:8080`.

## What's implemented in the prototype
- Timed curtain opening when loading each page
- Hero with muted autoplay looping mp4, poster fallback, pause/play, `playsinline`, `preload=none`, save-data and reduced-motion detection
- Scroll-triggered content reveals, image hover effects, responsive mobile navigation
- Kingdom Projects listing and project detail/support UI
- Interactive demonstration-only donation amount choices, without payment processing
- Mobile-friendly pages and reduced motion support

## Scope boundaries
- Figma frames were used as direction. This is a coded interpretation, not a pixel-perfect import of every Figma layer.
- No actual Paystack checkout, backend, database, donation collection, user accounts, or verified church content exists in this ZIP.
- No invented monetary progress or target values are shown.
- Church address, service times, project status, logo and contact details must be verified. The homepage contact email is intentionally a placeholder.
- Next production stage: convert to Next.js and build the separately confirmed Node.js + Express.js API, PostgreSQL and Paystack only after the church approves requirements and account details.
