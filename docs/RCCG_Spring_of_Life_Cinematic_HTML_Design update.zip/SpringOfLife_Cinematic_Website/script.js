(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const saveData = navigator.connection?.saveData === true;
  const heroVideo = $('heroVideo');
  const videoButton = $('videoToggle');
  const menuToggle = $('menuToggle');
  const nav = $('nav');
  let started = false;
  function revealSite(){ document.body.classList.add('is-ready'); }
  if(reduced){ revealSite(); } else { requestAnimationFrame(() => setTimeout(revealSite, 400)); }
  function setButton(paused){if(!videoButton)return;videoButton.textContent = paused ? '▶' : 'Ⅱ';videoButton.setAttribute('aria-label', paused ? 'Play background video' : 'Pause background video');}
  async function playHero(){
    if(!heroVideo || reduced || saveData || document.hidden) return;
    if(!started){ heroVideo.preload='metadata';heroVideo.load();started=true; }
    try {await heroVideo.play();heroVideo.classList.add('is-playing');setButton(false);} catch(_){setButton(true);}
  }
  function pauseHero(){if(heroVideo)heroVideo.pause();setButton(true);}
  if(heroVideo)heroVideo.addEventListener('error',()=>{heroVideo.classList.remove('is-playing');setButton(true);});
  if(!reduced && !saveData) window.addEventListener('load',playHero,{once:true});else setButton(true);
  if(videoButton && heroVideo)videoButton.addEventListener('click',()=>heroVideo.paused ? playHero() : pauseHero());
  document.addEventListener('visibilitychange',()=>{if(document.hidden)pauseHero();});
  const header = $('header');
  window.addEventListener('scroll',()=>header.classList.toggle('is-sticky',window.scrollY>95),{passive:true});
  if(menuToggle && nav)menuToggle.addEventListener('click',()=>{let open=nav.classList.toggle('is-open');menuToggle.setAttribute('aria-expanded',String(open));menuToggle.setAttribute('aria-label',open?'Close navigation':'Open navigation');});
  if(nav && menuToggle)nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('is-open');menuToggle.setAttribute('aria-expanded','false');}));
  if($('year'))$('year').textContent=new Date().getFullYear();
  const amountButtons=[...document.querySelectorAll('[data-amount]')];
  const amountInput=$('givingAmount');
  if(amountInput){amountButtons.forEach(b=>b.addEventListener('click',()=>{amountButtons.forEach(x=>{x.classList.remove('is-selected');x.setAttribute('aria-pressed','false');});b.classList.add('is-selected');b.setAttribute('aria-pressed','true');if(b.dataset.amount==='custom'){amountInput.focus();amountInput.select();}else{amountInput.value=b.dataset.amount;}}));}
  const preview=$('givingPreview');
  if(preview)preview.addEventListener('click',()=>{const value=Number(amountInput.value);$('givingStatus').textContent=Number.isFinite(value)&&value>=100?'This is a design-only preview for ₦'+value.toLocaleString('en-NG')+'. Payment processing is not enabled.':'Please enter an amount of at least ₦100.';});
  const blocks=document.querySelectorAll('[data-reveal]');
  if(!reduced && 'IntersectionObserver' in window){const io=new IntersectionObserver((entries)=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('is-visible');io.unobserve(entry.target);}});},{threshold:.12,rootMargin:'0px 0px -35px 0px'});blocks.forEach(el=>io.observe(el));}else blocks.forEach(el=>el.classList.add('is-visible'));
})();
