# RCCG Spring of Life Abuja — cinematic website prototype

This is an editable, self-contained HTML/CSS/JavaScript visual prototype. It is not the live official church website.

## View locally

Open `index.html` in Chrome, or run `python -m http.server 8080` from this folder and open http://localhost:8080. The project has no npm dependencies. Google Fonts are optional (fallback fonts work offline).

## What works

- Opening two-panel curtain reveal (CSS/JS), accessible reduced-motion fallback
- Video-led hero: muted loop, autoplay where permitted, `playsinline`, poster fallback, manual pause/play
- Saves video data by not loading/playing it when `navigator.connection.saveData` is true, and by using `preload="none"`
- Scroll-triggered reveal effects; image hover transformations; announcement marquee
- Responsive navigation and horizontally scrollable ministry cards on mobile
- Full homepage layout, from visitor actions through Kingdom Projects

## Important notes

- All photography and the hero video are **illustrative/generated demonstration assets**, not documentation of actual RCCG Spring of Life events or members.
- The packaged video is a lightweight looping montage made from still imagery, **not filmed church footage**. Replace with a short compressed approved church video for launch.
- Event times, exact church address, official contacts and project fundraising amounts are not known. These are intentionally **not fabricated**.
- The `mailto:hello@example.com` contact action is a demo placeholder. Replace before launch.
- Payment links do not take money. Build payment APIs separately in Node.js / Express.js, verify Paystack webhooks and isolate finance access.
- The visual prototype uses no backend. Your confirmed planned stack for the real site: Next.js + TypeScript + Tailwind + GSAP; Node.js + Express.js backend; Paystack; PostgreSQL per latest note, without Supabase.
- To move into Next.js, split each `<section>` into React components, move `assets/` to `public/assets/`, migrate the stylesheet to CSS modules or Tailwind and add client-side animation lifecycle cleanup. Do not wire DOM global listeners directly inside React renders.

## Files

`index.html`  – semantic layout and content
`styles.css` – design language, responsive styling, transitions, animation
`script.js`  – curtain, video rules, navigation, scroll-reveal and reduced-motion handling
`assets/`    – demo photo and video files
`docs/`      – implementation notes
